import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const TradeBotApp());

class TradeBotApp extends StatelessWidget {
  const TradeBotApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TradeBot Control',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF070B12),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4ADE80), brightness: Brightness.dark),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF101722),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int index = 0;
  bool running = false;
  final pages = const [DashboardPage(), BrokerPage(), SettingsPage(), MonitorPage(), ScannerPage()];
  @override
  Widget build(BuildContext context) {
    final titles = ['Dashboard','Broker','Trading Settings','Live Trades','Chart Scanner'];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF070B12),
        title: Text(titles[index], style: const TextStyle(fontWeight: FontWeight.w800)),
        actions: [IconButton(onPressed: (){}, icon: const Icon(Icons.notifications_none_rounded))],
      ),
      body: IndexedStack(index: index, children: [
        DashboardPage(running: running, onToggle: () => setState(() => running = !running)),
        const BrokerPage(), const SettingsPage(), const MonitorPage(), const ScannerPage(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.account_balance_outlined), selectedIcon: Icon(Icons.account_balance), label: 'Broker'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Settings'),
          NavigationDestination(icon: Icon(Icons.monitor_heart_outlined), selectedIcon: Icon(Icons.monitor_heart), label: 'Monitor'),
          NavigationDestination(icon: Icon(Icons.document_scanner_outlined), selectedIcon: Icon(Icons.document_scanner), label: 'Scanner'),
        ],
      ),
    );
  }
}

class CardBox extends StatelessWidget {
  final Widget child; const CardBox({super.key, required this.child});
  @override Widget build(BuildContext context) => Container(
    width: double.infinity, padding: const EdgeInsets.all(18), margin: const EdgeInsets.only(bottom: 14),
    decoration: BoxDecoration(color: const Color(0xFF0E151F), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white10)),
    child: child,
  );
}

class DashboardPage extends StatelessWidget {
  final bool running; final VoidCallback onToggle;
  const DashboardPage({super.key, this.running=false, required this.onToggle});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    CardBox(child: Row(children: [
      Container(width: 52,height:52,decoration: BoxDecoration(color: (running?Colors.green:Colors.red).withOpacity(.12),borderRadius: BorderRadius.circular(16)),child: Icon(running?Icons.play_arrow:Icons.pause,color: running?Colors.green:Colors.red,size:30)),
      const SizedBox(width:14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text(running?'BOT RUNNING':'BOT STOPPED',style: TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:running?Colors.green:Colors.red)),const SizedBox(height:4),Text(running?'Execution is enabled':'Execution is paused',style: const TextStyle(color:Colors.white54))])),
    ])),
    CardBox(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      const Text('XAUUSD',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)), const SizedBox(height:4), const Text('MT5 • Exness • Demo/Live account',style:TextStyle(color:Colors.white54)), const SizedBox(height:18),
      SizedBox(width:double.infinity,height:54,child:FilledButton.icon(onPressed:onToggle,icon:Icon(running?Icons.stop:Icons.play_arrow),label:Text(running?'STOP BOT':'START BOT',style:const TextStyle(fontWeight:FontWeight.w900))))
    ])),
    Row(children:[Expanded(child:_stat('Balance','R 140.00')),const SizedBox(width:10),Expanded(child:_stat('Equity','R 140.00'))]),
    Row(children:[Expanded(child:_stat('Open Trades','0')),const SizedBox(width:10),Expanded(child:_stat('P/L','R 0.00'))]),
    CardBox(child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Execution setup',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:12),_line('Lot size','0.01'),_line('Max trades','1'),_line('EA','Poverty Scalper Robot')]))
  ]);
  Widget _stat(String a,String b)=>CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Colors.white54)),const SizedBox(height:6),Text(b,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900))]));
  Widget _line(String a,String b)=>Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(a,style:const TextStyle(color:Colors.white60)),Text(b,style:const TextStyle(fontWeight:FontWeight.w800))]));
}

class BrokerPage extends StatelessWidget { const BrokerPage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Link MT4 / MT5 account',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Use the broker terminal login so the EA on the VPS can execute trades.',style:TextStyle(color:Colors.white54)),const SizedBox(height:18),
      _field('Broker','Exness'),_field('Platform','MT5'),_field('Account number','2100222617',keyboard:TextInputType.number),_field('Master password','••••••••',obscure:true),_field('Server','Exness-MT5Real'),
      const SizedBox(height:6),SizedBox(width:double.infinity,height:52,child:FilledButton(onPressed:(){},child:const Text('SAVE & LINK ACCOUNT',style:TextStyle(fontWeight:FontWeight.w900))))
    ])),
    CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Security',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),const SizedBox(height:8),const Text('Passwords must be encrypted and never displayed in plain text. The production version should use a secure VPS/terminal connection rather than a broker REST API.',style:TextStyle(color:Colors.white54,height:1.4))]))
  ]);
  Widget _field(String label,String value,{bool obscure=false,TextInputType? keyboard})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(obscureText:obscure,keyboardType:keyboard,controller:TextEditingController(text:value),decoration:InputDecoration(labelText:label)));
}

class SettingsPage extends StatefulWidget { const SettingsPage({super.key}); @override State<SettingsPage> createState()=>_SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage>{ String symbol='XAUUSD'; double lot=.01; double maxTrades=1;
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Trading settings',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:18),DropdownButtonFormField<String>(value:symbol,decoration:const InputDecoration(labelText:'Currency / Symbol'),items:['XAUUSD','EURUSD','GBPUSD','USDJPY'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x)=>setState(()=>symbol=x!)),const SizedBox(height:14),Text('Lot size: ${lot.toStringAsFixed(2)}'),Slider(value:lot,min:.01,max:.10,divisions:9,onChanged:(v)=>setState(()=>lot=v)),Text('Maximum trades: ${maxTrades.round()}'),Slider(value:maxTrades,min:1,max:5,divisions:4,onChanged:(v)=>setState(()=>maxTrades=v)),const SizedBox(height:8),const Text('Risk controls',style:TextStyle(fontWeight:FontWeight.w800)),SwitchListTile(value:true,onChanged:(_){},title:const Text('Stop after daily loss limit'),subtitle:const Text('Production version will enforce this on the execution server.')),]))]); }
}

class MonitorPage extends StatelessWidget { const MonitorPage({super.key}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Live account',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:14),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[_metric('Balance','R 140.00'),_metric('Equity','R 140.00'),_metric('P/L','R 0.00')])])),CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Open trades',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:20),const Center(child:Padding(padding:EdgeInsets.all(30),child:Column(children:[Icon(Icons.receipt_long_outlined,size:48,color:Colors.white24),SizedBox(height:10),Text('No open trades',style:TextStyle(color:Colors.white54))])))]),CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Trade history',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:10),const ListTile(leading:Icon(Icons.history),title:Text('No trades yet'),subtitle:Text('Executed trades will appear here.'))]))]);
 static Widget _metric(String a,String b)=>Column(children:[Text(a,style:const TextStyle(color:Colors.white54)),const SizedBox(height:5),Text(b,style:const TextStyle(fontWeight:FontWeight.w900))]); }

class ScannerPage extends StatefulWidget { const ScannerPage({super.key}); @override State<ScannerPage> createState()=>_ScannerPageState(); }
class _ScannerPageState extends State<ScannerPage>{ XFile? image; final picker=ImagePicker();
 Future<void> pick(bool camera) async { final x=await picker.pickImage(source:camera?ImageSource.camera:ImageSource.gallery); if(x!=null)setState(()=>image=x); }
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Neural Chart Scanner',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Upload a chart or use the camera for analysis.',style:TextStyle(color:Colors.white54)),const SizedBox(height:18),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:()=>pick(false),icon:const Icon(Icons.upload_file),label:const Text('UPLOAD'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:()=>pick(true),icon:const Icon(Icons.camera_alt),label:const Text('CAMERA')))]),const SizedBox(height:18),if(image!=null)Container(height:180,width:double.infinity,alignment:Alignment.center,decoration:BoxDecoration(color:Colors.black26,borderRadius:BorderRadius.circular(14)),child:Text(image!.name,style:const TextStyle(color:Colors.white54)))else const SizedBox(height:120,child:Center(child:Icon(Icons.analytics_outlined,size:64,color:Colors.white12))),const SizedBox(height:12),SizedBox(width:double.infinity,height:52,child:FilledButton.icon(onPressed:image==null?null:(){},icon:const Icon(Icons.auto_awesome),label:const Text('ANALYZE CHART',style:TextStyle(fontWeight:FontWeight.w900))))])),CardBox(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Scanner result',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:12),const Center(child:Text('NO TRADE',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900,color:Colors.orange))),const SizedBox(height:8),const Text('The real scanner engine will be connected in the next build. It should return BUY / SELL / NO TRADE plus entry, SL and TP when confidence is sufficient.',style:TextStyle(color:Colors.white54,height:1.4))]))]); }
}
