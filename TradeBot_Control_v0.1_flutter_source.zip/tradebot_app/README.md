# TradeBot Control — V0.1

Android-first Flutter starter for the trading-control app discussed in the chat.

## Included in V0.1
- Dashboard
- Start/Stop Bot control (UI state only)
- Broker MT4/MT5 account form
- Trading symbol, lot size and max-trade controls
- Live trade monitor UI
- Trade history UI
- Chart Scanner with camera/upload picker
- Dark trading-app style UI

## Important
This build is a UI prototype. It does **not** execute real trades yet.

The production execution design should use:
1. MT4/MT5 terminal running on a VPS.
2. An EA attached to the selected symbol.
3. A secure private control channel between the mobile app and the user's VPS/terminal agent.
4. The EA/terminal performs the actual broker execution.
5. No broker REST/third-party trading API is required.

Broker passwords must be encrypted and handled as secrets. Do not put live credentials in source code.

## Build
Install Flutter 3.47.x or newer, then:

    flutter pub get
    flutter run

For a test APK:

    flutter build apk --release

Flutter's current Android documentation describes APK and Play Store AAB release flows.
